<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GrupoBiene extends Model
{
    //
}
