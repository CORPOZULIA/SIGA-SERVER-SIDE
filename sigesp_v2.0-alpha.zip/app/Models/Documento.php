<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Documento extends Model
{
    protected $table = 'v2.documentos';


    public function activo(){

    	return $this->belongsTo('App\Models\Activo');
    }

    public function tipo_documento(){

    	return $this->hasOne('App\Models\TipoDocumento');
    }

    public function institucion(){

    	return $this->hasOne('App\Models\Institucion');
    }
}
