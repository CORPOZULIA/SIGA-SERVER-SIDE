<?php

namespace App\Http\Controllers\Modulos\bienes;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Activo;
use JWTAuth;
class Nuevo extends Controller
{
    public function nuevo_codigo($request){
    	$codigo = Activo::getCodigo();
    	$data = [
    		'codigo' => $codigo,
    		'error' => false,
    		'mensaje' => 'RECIBIDO',
    		'token' => JWTAuth::refresh($request->token),
    	];

    	return response($data, 200)->header('Content-Type', 'application/json');
    }
}
