<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubGrupo extends Model
{
    protected $table = 'v2.subgrupos';


   public function grupo(){

   		return $this->belogsTo('App\Models\Grupo');
	}


}
