<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Grupo extends Model
{
   protected $table = 'v_2.grupos';


   public function activos(){

   		return $this->hasMany('App\Models\Activo');
	}

	public function subgrupos(){

		return $this->hasMany('App\Models\SubGrupo');
	}

	public function estado(){

		return $this->belongsTo('App\Models\Estado','estado_grupo');
	}


}
